import Foundation

enum Availability: String, Codable, CaseIterable {
    case available = "Available"
    case onCall = "On a call"
    case busy = "Busy"
    case sleeping = "Sleeping"
}

enum EventKind: String, Codable {
    case callStarted, callEnded, sharingDisabled, sharingEnabled
}

enum EventSource: String, Codable {
    case callKit, manual
}

struct ActivityEvent: Identifiable, Codable {
    var id: UUID = UUID()
    let kind: EventKind
    let source: EventSource
    let occurredAt: Date
    var synced: Bool = false

    var title: String {
        switch kind {
        case .callStarted: return "Call started"
        case .callEnded: return "Call ended"
        case .sharingDisabled: return "Activity sharing turned off"
        case .sharingEnabled: return "Activity sharing turned on"
        }
    }
}

struct PartnerSnapshot {
    var name: String
    var availability: Availability
    var sharingEnabled: Bool
    var lastSeenAt: Date?
    var connectionUnknown: Bool
}
