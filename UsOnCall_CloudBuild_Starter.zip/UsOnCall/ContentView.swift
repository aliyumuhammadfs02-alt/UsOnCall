import SwiftUI

struct ContentView: View {
    @EnvironmentObject private var store: AppStore
    @State private var selectedTab = 0

    private let navy = Color(red: 0.025, green: 0.07, blue: 0.17)
    private let blue = Color(red: 0.12, green: 0.48, blue: 0.95)
    private let green = Color(red: 0.05, green: 0.78, blue: 0.43)

    var body: some View {
        ZStack {
            navy.ignoresSafeArea()
            VStack(spacing: 18) {
                HStack {
                    VStack(alignment: .leading, spacing: 3) {
                        Text("UsOnCall").font(.largeTitle.bold())
                        Text("M&A  •  ALWAYS TOGETHER")
                            .font(.caption2).tracking(2).foregroundStyle(.white.opacity(0.65))
                    }
                    Spacer()
                    Image(systemName: "heart.fill")
                        .font(.title).foregroundStyle(blue, green)
                }
                .padding(.horizontal)

                Picker("Section", selection: $selectedTab) {
                    Text("Home").tag(0)
                    Text("History").tag(1)
                    Text("Settings").tag(2)
                }
                .pickerStyle(.segmented).padding(.horizontal)

                if selectedTab == 0 { home }
                else if selectedTab == 1 { history }
                else { settings }
                Spacer(minLength: 0)
            }
            .padding(.top, 12)
        }
    }

    private var home: some View {
        ScrollView {
            VStack(spacing: 14) {
                statusCard(name: store.myName, status: store.availability.rawValue,
                           subtitle: store.sharingEnabled ? "Your sharing is on" : "Your sharing is off")
                statusCard(name: store.partnerName,
                           status: store.partnerConnectionUnknown ? "Connection unknown" :
                            (store.partnerSharingEnabled ? "Sharing on" : "Sharing off"),
                           subtitle: store.partnerLastSeen.map { "Last active " + $0.formatted(date: .abbreviated, time: .shortened) } ?? "No recent partner sync")
                VStack(alignment: .leading, spacing: 12) {
                    Text("Manual call backup").font(.headline)
                    HStack {
                        Button { store.setManualCall(true) } label: {
                            Label("On a call", systemImage: "phone.fill")
                                .frame(maxWidth: .infinity)
                        }.buttonStyle(.borderedProminent).tint(green)
                        Button { store.setManualCall(false) } label: {
                            Label("Available", systemImage: "checkmark")
                                .frame(maxWidth: .infinity)
                        }.buttonStyle(.bordered).tint(blue)
                    }
                    Toggle("Share my activity", isOn: Binding(
                        get: { store.sharingEnabled },
                        set: { store.setSharing($0) }
                    ))
                    .tint(green)
                }
                .padding().background(.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 20))
                Text("Automatic call detection is best-effort and depends on what iOS exposes.")
                    .font(.footnote).foregroundStyle(.white.opacity(0.6))
                    .frame(maxWidth: .infinity, alignment: .leading)
            }.padding()
        }
    }

    private func statusCard(name: String, status: String, subtitle: String) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text(name).font(.title2.bold())
                Spacer()
                Circle().fill(green).frame(width: 9, height: 9)
                Text(status).font(.subheadline.weight(.semibold))
            }
            Text(subtitle).font(.caption).foregroundStyle(.white.opacity(0.65))
        }
        .padding().background(
            LinearGradient(colors: [blue.opacity(0.24), green.opacity(0.13)], startPoint: .topLeading, endPoint: .bottomTrailing),
            in: RoundedRectangle(cornerRadius: 20)
        )
    }

    private var history: some View {
        List {
            if store.events.isEmpty {
                Text("No activity recorded yet.").foregroundStyle(.secondary)
            }
            ForEach(store.events) { event in
                VStack(alignment: .leading, spacing: 4) {
                    Text(event.title).font(.headline)
                    Text(event.occurredAt.formatted(date: .complete, time: .shortened))
                        .font(.caption).foregroundStyle(.secondary)
                    Text(event.source == .callKit ? "Automatic detection (CallKit)" : "Manual update")
                        .font(.caption2).foregroundStyle(.secondary)
                }.listRowBackground(Color.white.opacity(0.06))
            }
        }
        .scrollContentBackground(.hidden)
    }

    private var settings: some View {
        VStack(alignment: .leading, spacing: 14) {
            Label("M&A branding", systemImage: "heart.fill")
            Label("Navy, blue and emerald theme", systemImage: "paintpalette")
            Label("Previous history stays visible when sharing is off", systemImage: "clock.arrow.circlepath")
            Label("Mutual consent and private pairing required", systemImage: "lock.shield")
            Text("Firebase accounts, pairing, remote history and push delivery are integration steps.")
                .font(.footnote).foregroundStyle(.white.opacity(0.65))
        }.padding()
    }
}
