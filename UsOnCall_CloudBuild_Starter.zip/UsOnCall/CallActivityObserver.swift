import Foundation
import Combine
import CallKit

/// Best-effort observer for call state changes that iOS exposes to this app.
/// This is not a universal cross-app call monitor.
final class CallActivityObserver: NSObject, ObservableObject, CXCallObserverDelegate {
    private let observer = CXCallObserver()
    var onCallStateChanged: ((Bool) -> Void)?

    override init() {
        super.init()
        observer.setDelegate(self, queue: .main)
        publishCurrentState()
    }

    func callObserver(_ callObserver: CXCallObserver, callChanged call: CXCall) {
        publishCurrentState()
    }

    private func publishCurrentState() {
        let hasActiveCall = observer.calls.contains { !$0.hasEnded && $0.hasConnected }
        onCallStateChanged?(hasActiveCall)
    }
}
