import Foundation
import SwiftUI

@MainActor
final class AppStore: ObservableObject {
    @Published var myName = "Muhammad"
    @Published var partnerName = "Imaan"
    @Published var availability: Availability = .available
    @Published var sharingEnabled = true
    @Published var partnerSharingEnabled = true
    @Published var partnerConnectionUnknown = true
    @Published var partnerLastSeen: Date?
    @Published var events: [ActivityEvent] = []

    private let observer = CallActivityObserver()
    private let storageKey = "usoncall.events.v1"

    init() {
        loadEvents()
        observer.onCallStateChanged = { [weak self] active in
            guard let self, self.sharingEnabled else { return }
            self.setCallState(active, source: .callKit)
        }
    }

    func setManualCall(_ active: Bool) {
        guard sharingEnabled else { return }
        setCallState(active, source: .manual)
    }

    private func setCallState(_ active: Bool, source: EventSource) {
        let next: Availability = active ? .onCall : .available
        guard availability != next else { return }
        availability = next
        append(active ? .callStarted : .callEnded, source: source)
        // TODO: Send a minimal event to Firestore and trigger a partner push notification.
    }

    func setSharing(_ enabled: Bool) {
        guard sharingEnabled != enabled else { return }
        sharingEnabled = enabled
        append(enabled ? .sharingEnabled : .sharingDisabled, source: .manual)
        // TODO: Update users/{uid}.sharingEnabled in Firestore.
        // Keep previously recorded history visible when sharing is disabled.
    }

    private func append(_ kind: EventKind, source: EventSource) {
        events.insert(ActivityEvent(kind: kind, source: source, occurredAt: Date()), at: 0)
        saveEvents()
    }

    private func saveEvents() {
        guard let data = try? JSONEncoder().encode(events) else { return }
        UserDefaults.standard.set(data, forKey: storageKey)
    }

    private func loadEvents() {
        guard let data = UserDefaults.standard.data(forKey: storageKey),
              let decoded = try? JSONDecoder().decode([ActivityEvent].self, from: data) else { return }
        events = decoded
    }
}
