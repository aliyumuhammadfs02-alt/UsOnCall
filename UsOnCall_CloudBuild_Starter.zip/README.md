# UsOnCall ❤️ — iOS starter project

A native SwiftUI starter for Muhammad and Imaan. Branding: M&A, navy blue, electric blue and emerald green.

## What this starter includes
- SwiftUI dashboard, activity-sharing switch, partner status, history and settings.
- Local persistence for status/history while offline.
- A CallKit observer for call-state changes exposed to the app by iOS.
- Firebase integration points for authentication, Firestore synchronisation and push notifications.
- Firestore security-rule starting point and a Cloud Functions notification example.

## Important limitations
This is source code, not an installed or signed iPhone app. It has not been compiled or tested in Xcode.
A native iOS build, Apple signing, Firebase project, APNs configuration and device testing are required.

`CXCallObserver` reports call changes that iOS makes visible to the app. It does **not** guarantee universal monitoring of cellular, FaceTime, WhatsApp, Instagram, Snapchat, Telegram or other apps. Third-party VoIP visibility depends on their CallKit integration and iOS behaviour. Do not treat absence of an event as proof that no call occurred.

The app only records call start/end state and timestamps. It does not record audio, phone numbers, contacts, message contents or the other caller's identity.

## Build prerequisites
- A Mac with a compatible version of Xcode (needed to compile/sign the native iOS app).
- An Apple Developer account for device distribution and APNs capabilities.
- A Firebase project with Authentication, Cloud Firestore and Cloud Functions enabled.
- Add `GoogleService-Info.plist` to the Xcode app target (do not commit it publicly).
- Add the Firebase iOS SDK using Swift Package Manager: `FirebaseAuth`, `FirebaseFirestore`, `FirebaseFirestoreSwift`, `FirebaseMessaging`.
- Enable Push Notifications and Background Modes only as needed; background execution is not guaranteed.
- Set a unique bundle identifier and configure APNs in Firebase.

## Suggested Xcode setup
1. In Xcode, create an iOS App project named `UsOnCall`, Interface: SwiftUI, Language: Swift.
2. Replace/add the files in `UsOnCall/` to the app target.
3. Add the Firebase packages listed above and `GoogleService-Info.plist`.
4. Add the `CallKit` framework (system framework).
5. Configure signing and capabilities.
6. Deploy `Firebase/firestore.rules` and the Cloud Functions in `Firebase/functions/`.
7. Test with two consenting devices. Verify real call-state visibility separately for each call service.

## Data model (recommended)
- `users/{uid}`: displayName, pairedUid, sharingEnabled, presence, lastSeenAt, updatedAt
- `users/{uid}/events/{eventId}`: kind (`callStarted`, `callEnded`, `sharingDisabled`, `sharingEnabled`), source (`callKit` or `manual`), occurredAt, syncState
- Store only the minimum necessary event data. Keep history visible when sharing is disabled, as requested. Each user can correct/delete their own records; shared access must be explicit and mutually agreed.

## Offline behaviour
The app stores local status/events and Firestore can cache data and queue writes. Push notifications and live partner updates require connectivity. If a phone is offline, the partner should see `Connection unknown` after a heartbeat timeout—not a claim that the person deliberately went offline.
