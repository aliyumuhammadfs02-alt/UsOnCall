# Build UsOnCall from an iPhone

## What this package does
This adds XcodeGen and Codemagic cloud-build configuration to the SwiftUI starter.
It is still a starter project, not a finished production app. Firebase auth, pairing,
remote history, device-token registration and production push delivery remain to be implemented.

## Step 1 — Create a private GitHub repository
1. Open https://github.com in Safari and sign in or create an account.
2. Create a new repository named `UsOnCall`.
3. Set it to **Private**.
4. Upload the contents of this ZIP (not the ZIP file itself) to the repository.
5. Do not upload `GoogleService-Info.plist`, Apple keys, certificates, or passwords.

## Step 2 — Create a Codemagic account
1. Open https://codemagic.io and sign up.
2. Connect GitHub and grant access only to the private UsOnCall repository.
3. Add the repository as an iOS app.
4. Codemagic should detect `codemagic.yaml`.
5. Start the `usoncall-ios` workflow.

This first workflow is an unsigned compile check. An unsigned build is not installable on a physical iPhone.

## Step 3 — Firebase (next implementation stage)
Create a Firebase project, register the iOS bundle ID `com.usoncall.ma`,
download `GoogleService-Info.plist`, and add it to the Xcode target through
the project/repository workflow. Configure Authentication, Firestore, APNs and
Cloud Functions. Never post Firebase service-account private keys or Apple signing keys in chat.

## Step 4 — Install on both iPhones
For TestFlight distribution, Apple Developer Program membership and signing are required.
Configure an App Store Connect API key and signing in Codemagic, then distribute
the build to Muhammad and Imaan through TestFlight.

## Important
- The initial cloud workflow only checks compilation; it does not produce a signed,
  installable app.
- This starter does not yet implement real account creation, pairing, remote
  synchronisation, last-active heartbeats, activity-sharing alerts, or push-token
  registration. Those require the next coding stage.
- CallKit detection is best-effort. It cannot promise monitoring of every third-party
  app's calls. A missing event is not proof that no call happened.
- Offline records can sync later, but a partner cannot receive live notifications
  while the sending phone or receiving phone has no network.
