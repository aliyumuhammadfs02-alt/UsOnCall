import { onDocumentCreated } from "firebase-functions/v2/firestore";
import { initializeApp } from "firebase-admin/app";
import { getFirestore } from "firebase-admin/firestore";
import { getMessaging } from "firebase-admin/messaging";

initializeApp();
const db = getFirestore();

/**
 * Starter notification trigger.
 * Production TODO: verify the event owner is paired with the recipient,
 * validate event kinds, rate-limit, and avoid sending duplicate notifications.
 */
export const notifyPartnerOfActivity = onDocumentCreated(
  "users/{uid}/events/{eventId}",
  async (event) => {
    const uid = event.params.uid;
    const data = event.data?.data();
    if (!data) return;

    const userSnap = await db.doc(`users/${uid}`).get();
    const user = userSnap.data();
    const partnerUid = user?.pairedUid;
    if (!partnerUid || user?.sharingEnabled !== true) return;

    const partnerSnap = await db.doc(`users/${partnerUid}`).get();
    const token = partnerSnap.data()?.pushToken;
    if (!token) return;

    const labels: Record<string, string> = {
      callStarted: "A partner's device reported an active call.",
      callEnded: "A partner's device reported that a call ended.",
      sharingDisabled: "Your partner turned off activity sharing.",
      sharingEnabled: "Your partner turned activity sharing back on."
    };
    const body = labels[data.kind] ?? "Your partner's activity was updated.";

    await getMessaging().send({
      token,
      notification: { title: "UsOnCall 💙💚", body },
      data: { eventId: event.params.eventId, kind: String(data.kind ?? "activity") }
    });
  }
);
